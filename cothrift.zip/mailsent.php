<?php
require 'vendor/autoload.php'; // This loads the SendGrid library
require_once "utilities.php";
function send_email($to, $full_name)
{
    // $to = $_GET['email'];
    // $full_name = $_GET['full_name'];
    $subject = "CoThrift - Email Verification";
    $code = substr(uniqid(), -4);



    // HTML content for the new user email
    $msg = "
    <!DOCTYPE html>
    <html>
    <head>
        <style>
            /* Add your CSS styles here */
            body {
                font-family: Arial, sans-serif;
                text-align: center; /* Center-align the body content */
                background-color: #e0f7fa; /* Light blue background for a fresh look */
                color: #004d40; /* Dark green text for a sustainable feel */
            }
            .container {
                background-color: #ffffff;
                padding: 20px;
                border-radius: 5px;
                box-shadow: 0 0 5px rgba(0, 0, 0, 0.1);
                margin: 0 auto; /* Center the container */
                width: 80%; /* Set a width for better presentation */
                max-width: 600px; /* Limit maximum width */
            }
            .header {
                background-color: #004d40;
                color: #ffffff;
                padding: 10px;
                border-radius: 5px 5px 0 0;
            }
            .footer {
                background-color: #004d40;
                color: #ffffff;
                padding: 10px;
                border-radius: 0 0 5px 5px;
                margin-top: 20px;
            }
            .code {
                font-size: 1.5em;
                color: #d32f2f;
            }
        </style>
    </head>
    <body>
        <div class='container'>
            <div class='header'>
                <h2>Welcome to CoThrift!</h2>
            </div>
            <p>Hi " . $full_name . ",</p>
            <p>Thank you for joining our community dedicated to sustainability and thriftiness. Together, we can make a difference!</p>
            <p>Your verification code is:</p>
            <p class='code'><strong>" . $code . "</strong></p>
            <p>Please use this code to complete your registration.</p>
            <div class='footer'>
                <p>Let's make the world a better place, one thrift at a time!</p>
            </div>
        </div>
    </body>
    </html>
    
    ";

    $email = new \SendGrid\Mail\Mail();
    $email->setFrom("diwaanone@gmail.com", "CoThrift");
    $email->setSubject($subject);
    $email->addTo($to);
    $email->addContent("text/html", $msg);

    $sendgrid = new \SendGrid('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');

    try {
        $response = $sendgrid->send($email);
        if ($response->statusCode() == 202) {
            return $code;
        } else {
            return "Email not sent";
        }
    } catch (Exception $e) {
        return $e;
    }

}

function send_email_for_requests($to, $full_name, $items, $member_id)
{
    // $to = $_GET['email'];
    // $full_name = $_GET['full_name'];
    $subject = "CoThrift - New Request Notification";
    $code = substr(uniqid(), -4);

    $buyer_info = get_member_details_by_id($member_id);

    // HTML content for the new user email
    $msg = "
    <!DOCTYPE html>
    <html>
    <head>
        <style>
            /* Add your CSS styles here */
            body {
                font-family: Arial, sans-serif;
                text-align: center; /* Center-align the body content */
                background-color: #e0f7fa; /* Light blue background for a fresh look */
                color: #004d40; /* Dark green text for a sustainable feel */
            }
            .container {
                background-color: #ffffff;
                padding: 20px;
                border-radius: 5px;
                box-shadow: 0 0 5px rgba(0, 0, 0, 0.1);
                margin: 0 auto; /* Center the container */
                width: 80%; /* Set a width for better presentation */
                max-width: 600px; /* Limit maximum width */
            }
            .header {
                background-color: #004d40;
                color: #ffffff;
                padding: 10px;
                border-radius: 5px 5px 0 0;
            }
            .footer {
                background-color: #004d40;
                color: #ffffff;
                padding: 10px;
                border-radius: 0 0 5px 5px;
                margin-top: 20px;
            }
            .items {
                text-align: left;
                margin: 20px 0;
            }
            .items th, .items td {
                padding: 10px;
                border: 1px solid #004d40;
            }
            .logo {
                width: 100px;
                margin: 20px auto;
            }
        </style>
    </head>
    <body>
        <div class='container'>
            <div class='header'>
                <img src='CoThrift.svg' alt='CoThrift Logo' class='logo' style='width: 100px;'>
                <h2>New Request Notification</h2>
            </div>
            <p>Hi " . $full_name . ",</p>
            <p>You have received a new request from an interested party. Here are the details:</p>
            <p><strong>Name:</strong> " . $buyer_info['name'] . "</p>
            <p><strong>Email:</strong> " . $buyer_info['email'] . "</p>
            <p>Details of the requested items:</p>
            <table class='items'>
                <tr>
                    <th>Item</th>
                    <th>Quantity</th>
                </tr>";
                foreach ($items as $item) {
                    $msg .= "<tr>
                                <td>" . who_is_item($item['item_id']) . "</td>
                                <td>" . $item['quantity'] . "</td>
                             </tr>";
                }
    $msg .= "</table>
            <div class='footer'>
                <p>Thank you for being a part of CoThrift!</p>
            </div>
        </div>
    </body>
    </html>
    ";

    $email = new \SendGrid\Mail\Mail();
    $email->setFrom("diwaanone@gmail.com", "CoThrift");
    $email->setSubject($subject);
    $email->addTo($to);
    $email->addContent("text/html", $msg);

    $sendgrid = new \SendGrid('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');

    try {
        $response = $sendgrid->send($email);
        if ($response->statusCode() == 202) {
            return $code;
        } else {
            return "Email not sent";
        }
    } catch (Exception $e) {
        return $e;
    }

}

?>